
const board = document.getElementById('board');
const restartButton = document.getElementById('restart');

let currentPlayer = 'X';


function makeMove(cell) {

    const index = cell.dataset.index; // Obt�n el �ndice de la celda

    //Realiza una solicitud POST al servidor para registrar la jugada
    fetch("Api/game", {
        method: 'POST', // M�todo POST
        headers: {
            'Content-Type': "application/json" // Especifica el tipo de contenido como JSON
        },

        body: JSON.stringify({ index: parseInt(index) }) // Convierte el �ndice a n�mero y env�a como JSON
    })
        .then(response => response.json()) // Convierte la respuesta a JSON
        .then(data => {

            // Maneja la respuesta del servidor
            console.log("Respuesta del servidor despu�s de la jugada", data);

            // L�gica para actualizar la interfaz con el nuevo estado del juego
            for (let i = 0; i < data.board.length; i++) {
                for (let j = 0; j < data.board[i].length; j++) {

                    const cellIndex = i * 3 + j;
                    const cell = document.querySelector(`[data-index='${cellIndex}']`);
                    cell.textContent = data.board[i][j];


                }
            }

            // Puedes mostrar un mensaje en la interfaz si hay un ganador o empate
            if (data.isGameOver) {
                const message = document.getElementById('message'); // Cambia 'message' al ID real de tu elemento de mensaje
                message.textContent = data.message;
            }
        })

    //.catch(error => {

    //    // Maneja los errores
    //    console.error("Error al realizar la jugada", error);

    //});
}

// Agrega un evento de clic a cada celda del tablero
const cells = document.querySelectorAll('.cell');

cells.forEach(cell => {

    cell.addEventListener("click", () => {

        // Llama a la funci�n makeMove cuando se hace clic en una celda
        makeMove(cell);

        if (cell === '' && data.isGameOver) {
            cell = currentPlayer;
            currentPlayer = (currentPlayer === "X") ? "O" : "X"
        }

    });
});

